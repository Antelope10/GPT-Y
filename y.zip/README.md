# GPT-Y
Use text_loader.py to clean text from a selected batch in the texts directory and copy it into train.txt.
model.py and colab_model.ipynb are nearly identical, but have different hyperparameters. Both define a transformer model, load parameters from the checkpoints directory, train the model, and generate text.
